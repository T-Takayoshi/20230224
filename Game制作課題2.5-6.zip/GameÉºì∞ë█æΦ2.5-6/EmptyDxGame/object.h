#pragma once
class object
{
};

