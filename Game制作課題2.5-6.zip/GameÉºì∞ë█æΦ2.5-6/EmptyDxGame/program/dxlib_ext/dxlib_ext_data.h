#pragma once
#include <string>

namespace dxe {
	extern std::string g_x_file_hedder_str;
}

