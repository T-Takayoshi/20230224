

class Player {
	Player();
	~Player();

public:
private:
};
