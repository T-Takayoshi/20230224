#pragma once

class Player {
public:

	Player();

	int a = 0;

private:
};
