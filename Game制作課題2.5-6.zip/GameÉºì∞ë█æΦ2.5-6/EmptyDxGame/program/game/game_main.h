#pragma once
void gameMain( float delta_time );
void gameEnd();
